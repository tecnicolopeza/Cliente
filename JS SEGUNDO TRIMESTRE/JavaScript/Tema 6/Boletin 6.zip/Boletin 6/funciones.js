addEventListener('load', inicializarEventos, false);

var conexion1;
var conexion2;
var tiempo;

function inicializarEventos() {
    conexion1 = new XMLHttpRequest();
    conexion1.onreadystatechange = procesarComunidad;
    conexion1.open('GET', 'cargar_comunidades_autonomas.php', true);
    conexion1.send();


    var ob = document.getElementById('comunidad');
    ob.addEventListener('change', comunidadChange, false);

    var ob2 = document.getElementById('provinciaS');
    ob2.addEventListener('change', datosProvincia, false);

    var ob3 = document.getElementById('cancelar');
    ob3.addEventListener('click', termiarConexion, false);
}

function comunidadChange(e) {
    conexion2 = new XMLHttpRequest();
    conexion2.onreadystatechange = procesarProvincias;
    conexion2.open('GET', 'cargar_provincias.php?cod=' + e.target.value, true);
    console.log(e.target.value);
    conexion2.send();
    limpiarProvincias();
    tiempo = setTimeout("finDeEspera()", 3000);
}

function procesarComunidad() {
    var comunidades = document.getElementById("comunidad");
    var respuesta = document.getElementById("respuesta");
    if (conexion1.readyState == 4) {
        respuesta.innerHTML = "";
        var datos = JSON.parse(conexion1.responseText);
        for (var f = 0; f < datos.length; f++) {
            comunidades.insertAdjacentHTML("beforeend", "<option name='cod'  value='" + datos[f].id + "'>" + datos[f].nombre + "</option>");
        }

    } else {
        respuesta.innerHTML = "Cargando Comunidades...";
    }
}

function procesarProvincias() {
    var provincias = document.getElementById("provinciaS");
    var respuesta = document.getElementById("respuesta");
    if (conexion2.readyState == 4) {
        respuesta.innerHTML = "";
        var xml = conexion2.responseXML;
        var nombre = xml.getElementsByTagName('nombre');
        for (let i = 0; i < nombre.length; i++) {
            provincias.insertAdjacentHTML("beforeend", "<option name='cod'  value='" + nombre[i].firstChild.nodeValue + "'>" + nombre[i].firstChild.nodeValue + "</option>");
        }
        clearTimeout(tiempo);
    } else {
        respuesta.innerHTML = "Cargando Provincias...";
    }
}

function datosProvincia(ev) {
    var respuesta = document.getElementById("respuesta");
    if (conexion2.readyState == 4) {
        respuesta.innerHTML = "";
        var xml = conexion2.responseXML;
        var nombre = xml.getElementsByTagName('nombre');
        var id = xml.getElementsByTagName('id');
        for (let i = 0; i < nombre.length; i++) {
            if (nombre[i].firstChild.nodeValue == ev.target.value) {
                respuesta.innerHTML = "Id:" + id[i].firstChild.nodeValue + ",nombre:" + nombre[i].firstChild.nodeValue;
            }
        }
    } else {
        respuesta.innerHTML = "Cargando datos...";
    }

}

function limpiarProvincias() {
    var provincias = document.getElementById("provinciaS");
    for (let i = provincias.options.length; i >= 0; i--) {
        provincias.remove(i);
    }
    provincias.insertAdjacentHTML("beforeend",'<option name="cod" value="0">Seleccionar...</option>');
}

function finDeEspera() {
    var respuesta = document.getElementById("respuesta");
    conexion2.abort();
    respuesta.innerHTML = 'Servidor saturado.';
}

function termiarConexion(){
    var respuesta = document.getElementById("respuesta");
    conexion2.abort();
    clearTimeout(tiempo);
    respuesta.innerHTML = 'Conexión terminada.';
}